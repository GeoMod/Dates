import Foundation

let calendar = Calendar.current
let rightNow = Date()

// Create date from components
let dateComponents = DateComponents(calendar: calendar, year: 1996, month: 6, day: 11)
let composedDate = calendar.date(from: dateComponents)


// Get components
let componentsFromRightNow = calendar.dateComponents([.year, .month, .day, .hour, .minute], from: rightNow)
    // Looks like this to start
//     let dayOfWeekExample = calendar.component(<#T##component: Calendar.Component##Calendar.Component#>, from: <#T##Date#>)
    // fill in the "component" you want in (dot)notation.
let dayOfWeek = calendar.component(.weekday, from: rightNow)

enum WeekDays: Int {
	case Sunday = 1
	case Monday
	case Tuesday
	case Wednesday
	case Thursday
	case Friday
	case Saturday
}

func getDayOfWeekFrom(component: Int) -> WeekDays? {
	// Do something with the weekday.
//	let thing = WeekDays(rawValue: component)
	print(WeekDays(rawValue: component) ?? "Nil")

	return WeekDays(rawValue: component)
}

getDayOfWeekFrom(component: dayOfWeek)

// Adding a component to a date (like 30 days from now).
let tenDaysFromNow = calendar.date(byAdding: .day, value: 10, to: rightNow)
let fortyDaysAgo = calendar.date(byAdding: .day, value: -40, to: rightNow)

// Get beginning of component.
let beginningOfDay = calendar.dateInterval(of: .day, for: rightNow)?.start
let beginningOfMonth = calendar.dateInterval(of: .month, for: rightNow)?.start

// Get time intervals between two dates
let monthInterval = calendar.dateInterval(of: .month, for: rightNow)
let timePeriod = calendar.dateComponents([.day], from: monthInterval!.start, to: monthInterval!.end)
// This gives you back the time interval you just captured from "timePeriod".
let minutesInMonth = timePeriod.minute

// Days since our "composedDate".
let aVeryLongTime = calendar.dateComponents([.hour, .minute, .second], from: composedDate!, to: rightNow).minute


// Find particular date from array of dates.
let currentCalendar = Calendar.current
let formatter = DateFormatter()

var dates = (0...7).compactMap {
	currentCalendar.date(byAdding: .day, value: $0, to: Date())
}
formatter.dateStyle = .medium
formatter.timeStyle = .none


dates.shuffle()
dates.forEach {
	if currentCalendar.isDateInToday($0) {
		print("Formatted date is \(formatter.string(from: $0))")
		print("Matched date is \($0)")
	} else {
		print("Nope Ninja")
	}
}

